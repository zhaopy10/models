mAP = 0.66
the performance is ok, but still not satisfactory.
