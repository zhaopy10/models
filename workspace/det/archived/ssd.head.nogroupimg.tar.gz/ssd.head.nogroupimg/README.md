mAP = 0.45
This performance seems ok, but inference test in reality is very poor. This issue is due to using keep_aspect_ratio_resizer, but no idea about the details.
