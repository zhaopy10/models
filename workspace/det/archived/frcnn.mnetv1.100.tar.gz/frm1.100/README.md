Not successfully trained yet. Still with bugs.
